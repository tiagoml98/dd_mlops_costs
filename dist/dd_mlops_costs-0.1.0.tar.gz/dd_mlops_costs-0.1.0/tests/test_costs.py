import os
import time
import unittest

from dd_mlops_costs import report_job_cost, start_timer, get_elapsed_time
from unittest.mock import patch

class TestCostTracker(unittest.TestCase):
    def setUp(self):
        # Set environment variables for a Glue environment.
        os.environ["JOB_ENVIRONMENT"] = "glue"
        os.environ["GLUE_WORKER_TYPE"] = "G.1X"
        os.environ["GLUE_NUMBER_OF_WORKERS"] = "2"
        os.environ["DATADOG_API_KEY"] = "test_api_key"
    
    def test_glue_cost_calculation(self):
        start_timer()
        duration = 1  # Simulate a 1-second duration
        cost = report_job_cost(cnpj="1234567890001", duration_seconds=duration)
        expected = 2 * 1 * (duration / 3600) * 0.44  # For G.1X with 2 workers at 0.44 USD/DPU-hour
        self.assertAlmostEqual(cost, expected, places=6)
    
    # Example: Using unittest.mock to simulate a Boto3 API response.
    @patch('dd_mlops_costs.pricing.boto3.client')
    def test_emr_pricing_with_mock(self, mock_client):
        # Setup a fake response for get_products
        fake_price_json = (
            '{"terms": {"OnDemand": {'
            '"T1": {"priceDimensions": {"D1": {"unit": "Hrs", "pricePerUnit": {"USD": "0.200"}}}}'
            '}}}'
        )
        mock_client.return_value.get_products.return_value = {
            'PriceList': [fake_price_json]
        }
        # Call the pricing function and check that it returns the mocked price.
        from dd_mlops_costs.pricing import get_emr_instance_price
        price = get_emr_instance_price("us-west-1", "m5.xlarge")
        self.assertAlmostEqual(price, 0.200, places=3)

if __name__ == '__main__':
    unittest.main()